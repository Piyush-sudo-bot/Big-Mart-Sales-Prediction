import React from 'react';
import { Star, ShoppingCart, Heart } from 'lucide-react';

interface Product {
  id: number;
  title: string;
  category: string;
  image: string;
  price: string;
  originalPrice?: string;
  rating: number;
  reviews: number;
}

const ProductShowcase: React.FC = () => {
  const products: Product[] = [
    {
      id: 1,
      title: "Fresh Organic Fruits",
      category: "Fruits & Vegetables",
      image: "https://images.pexels.com/photos/1132047/pexels-photo-1132047.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      price: "$24.99",
      originalPrice: "$29.99",
      rating: 4.8,
      reviews: 234
    },
    {
      id: 2,
      title: "Premium Grocery Collection",
      category: "Grocery & Pantry",
      image: "https://images.pexels.com/photos/1005638/pexels-photo-1005638.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      price: "$45.99",
      originalPrice: "$52.99",
      rating: 4.9,
      reviews: 189
    },
    {
      id: 3,
      title: "Organic Vegetables Bundle",
      category: "Organic Produce",
      image: "https://images.pexels.com/photos/1300972/pexels-photo-1300972.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      price: "$19.99",
      rating: 4.7,
      reviews: 156
    },
    {
      id: 4,
      title: "Dairy & Fresh Products",
      category: "Dairy & Eggs",
      image: "https://images.pexels.com/photos/1188083/pexels-photo-1188083.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
      price: "$32.99",
      rating: 4.6,
      reviews: 98
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Featured Products
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our handpicked selection of fresh, quality products sourced from trusted suppliers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 group">
              <div className="relative overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4">
                  <button className="bg-white/80 hover:bg-white p-2 rounded-full shadow-md transition-colors">
                    <Heart className="h-4 w-4 text-gray-600 hover:text-red-500" />
                  </button>
                </div>
                {product.originalPrice && (
                  <div className="absolute top-4 left-4 bg-red-500 text-white px-2 py-1 rounded text-sm font-medium">
                    Sale
                  </div>
                )}
              </div>
              
              <div className="p-6">
                <div className="mb-2">
                  <span className="text-sm text-emerald-600 font-medium">{product.category}</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{product.title}</h3>
                
                <div className="flex items-center mb-3">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600 ml-2">({product.reviews})</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl font-bold text-gray-900">{product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">{product.originalPrice}</span>
                    )}
                  </div>
                  <button className="bg-emerald-500 hover:bg-emerald-600 text-white p-2 rounded-full transition-colors">
                    <ShoppingCart className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <button className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200">
            View All Products
          </button>
        </div>
      </div>
    </section>
  );
};

export default ProductShowcase;