import React, { useState } from 'react';
import { Menu, X, ShoppingCart, User } from 'lucide-react';

const Navigation: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="absolute top-0 left-0 right-0 z-50 bg-white/10 backdrop-blur-md border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <ShoppingCart className="h-8 w-8 text-white mr-2" />
            <span className="text-xl font-bold text-white">Big Mart</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <a href="#" className="text-white hover:text-emerald-300 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200">
                Home
              </a>
              <a href="#" className="text-white/80 hover:text-emerald-300 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200">
                Services
              </a>
              <a href="#" className="text-white/80 hover:text-emerald-300 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200">
                About Us
              </a>
              <a href="#" className="text-white/80 hover:text-emerald-300 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200">
                Contact Us
              </a>
            </div>
          </div>

          {/* Login Button */}
          <div className="hidden md:block">
            <button className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center">
              <User className="h-4 w-4 mr-2" />
              Login
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="text-white hover:text-emerald-300 p-2 rounded-md"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white/10 backdrop-blur-md border-t border-white/20">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <a href="#" className="text-white hover:text-emerald-300 block px-3 py-2 rounded-md text-base font-medium">
              Home
            </a>
            <a href="#" className="text-white/80 hover:text-emerald-300 block px-3 py-2 rounded-md text-base font-medium">
              Services
            </a>
            <a href="#" className="text-white/80 hover:text-emerald-300 block px-3 py-2 rounded-md text-base font-medium">
              About Us
            </a>
            <a href="#" className="text-white/80 hover:text-emerald-300 block px-3 py-2 rounded-md text-base font-medium">
              Contact Us
            </a>
            <button className="bg-emerald-500 hover:bg-emerald-600 text-white w-full px-3 py-2 rounded-md text-base font-medium transition-colors duration-200 flex items-center justify-center mt-4">
              <User className="h-4 w-4 mr-2" />
              Login
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navigation;