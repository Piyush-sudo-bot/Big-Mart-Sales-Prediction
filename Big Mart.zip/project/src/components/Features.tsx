import React from 'react';
import { Truck, Shield, Clock, Award } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Truck className="h-8 w-8 text-emerald-500" />,
      title: "Free Delivery",
      description: "Free delivery on orders over $50. Fast and reliable shipping to your doorstep."
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-500" />,
      title: "Quality Guarantee",
      description: "We guarantee the freshness and quality of all our products or your money back."
    },
    {
      icon: <Clock className="h-8 w-8 text-orange-500" />,
      title: "24/7 Support",
      description: "Our customer support team is available round the clock to help you."
    },
    {
      icon: <Award className="h-8 w-8 text-purple-500" />,
      title: "Best Prices",
      description: "Competitive prices with regular discounts and special offers for members."
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Why Choose Big Mart?
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            We're committed to providing the best shopping experience with quality products and exceptional service
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center group">
              <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:bg-emerald-50 transition-colors duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;